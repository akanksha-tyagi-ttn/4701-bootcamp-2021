package com.ttn_assignment_javaone;
import java.util.Scanner;

public class LetterOccurrence{
    public static void main(String[] args)
    {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the string::  ");
        String stringToTest= input.nextLine();
        System.out.println(stringToTest);
        System.out.print("Enter the character: ");
        char ch = input.next().charAt(0);
        findCharacterDuplicateOccurrence(stringToTest,ch); // calling the function
    }
    static void findCharacterDuplicateOccurrence(String stringToTest,char ch)
    {
        int total_length=stringToTest.length();
        int totalAfterRemoval_length=stringToTest.toLowerCase().replace(String.valueOf(ch),"").length();
        int character_count=total_length-totalAfterRemoval_length;
        //System.out.println(total_length+" :: "+totalAfterRemoval_length+"  "+character_count);
        System.out.println("The total number of occurrence of character: "+ch+" is ::"+character_count);
    }
}
