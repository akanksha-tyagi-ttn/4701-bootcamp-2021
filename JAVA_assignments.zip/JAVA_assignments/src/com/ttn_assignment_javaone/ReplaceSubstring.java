package com.ttn_assignment_javaone;
import java.util.Scanner;
public class ReplaceSubstring {
    public static void main(String[] args)
    {
        stringToReplaceFunction();
    }
    static void stringToReplaceFunction()
    {
        Scanner input=new Scanner(System.in);
        System.out.print("Enter the string:: ");
        String stringToTest= input.nextLine();
        System.out.println(stringToTest);

        System.out.print("Enter the string to replace:: ");
        String toReplace=input.nextLine();

        System.out.print("Enter the string to replace the previous string with:: ");
        String toReplaceWith=input.nextLine();
        // print replaced string
        System.out.println(stringToTest.replace(toReplace,toReplaceWith)); // answer
    }
}
