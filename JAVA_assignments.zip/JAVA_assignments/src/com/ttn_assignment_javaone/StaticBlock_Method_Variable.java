package com.ttn_assignment_javaone;
public class StaticBlock_Method_Variable
{
    static int age=24; // static variables
    static   // static block
    {
        String firstName="Akanksha";
        System.out.print("First Name: "+firstName+".");
        System.out.println("     //firstName is in static block//");
    }
    static void printLastName()
    {
        String lastName="Tyagi";
        System.out.print("LastName: "+lastName+".");
        System.out.println("   //lastName is in static method//");
    }
    public static void main(String[] args)  // static method
    {
        printLastName();
        System.out.print("My age is: "+age+" years.");
        System.out.println("    //age is static variable//");
    }
}
