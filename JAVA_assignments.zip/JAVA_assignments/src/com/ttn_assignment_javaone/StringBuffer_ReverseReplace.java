package com.ttn_assignment_javaone;
import java.util.Scanner;

public class StringBuffer_ReverseReplace
{
    static Scanner input=new Scanner(System.in);
    public static void main(String[] args)
    {
        stringBufferOperations();
    }
    static void stringBufferOperations()
    {
        System.out.print("enter the string of your choice: ");
        String yourChoice=input.nextLine();
        StringBuffer string_one=new StringBuffer(yourChoice);
        System.out.println("the reversed String is: \n*"+string_one.reverse()+"*");
        System.out.print("remove character from index 4 to 9 of a reversed String: \n*"+
                string_one.replace(4,9,"")+"*");
    }
}
// string which will be reversed and then remove the characters from index 4-9 !! Ok TATAT