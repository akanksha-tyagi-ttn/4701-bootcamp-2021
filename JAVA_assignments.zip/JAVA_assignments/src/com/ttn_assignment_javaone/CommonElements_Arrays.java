package com.ttn_assignment_javaone;
import java.util.Scanner;
public class CommonElements_Arrays
{
    static Scanner input=new Scanner(System.in);
    public static void main(String[] args)
    {
        System.out.println("Enter the size of the array1 and array2: ");
        int size1= input.nextInt(); int size2=input.nextInt();
        int[] arrInt1=new int[size1];  // initializing array1
        int[] arrInt2=new int[size2]; // initializing array2
        System.out.println("Enter the elements in the array1::  ");
        inputArrayElements(arrInt1,size1);
        System.out.println("Enter the elements in the array2::  "); inputArrayElements(arrInt2,size2);
        commonElement(arrInt1,arrInt2);
    }

    static void inputArrayElements(int[] intArray,int size)
    {
        for(int i=0;i<size;i++)
            intArray[i]=input.nextInt();
    }
    static void commonElement(int[] arr1,int[]arr2)
    {
        String resultsArray="";
        for(int first=0;first<arr1.length; first++)
        {
            for(int second=0;second<arr2.length;second++)
            {
                if(arr1[first]==arr2[second])
                {
                    resultsArray+=arr1[first]+" "; break;
                }
            } // inner loop
        }//outer loop
        if(resultsArray.length()>0)
                System.out.println("the common elements are: "+resultsArray);
        else
            System.out.println("No common elements found!!");
    }
}
