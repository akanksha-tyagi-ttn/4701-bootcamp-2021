package com.ttn_assignment_javaone;
import java.util.Scanner;

class Bank
{    final private float general_rateOfInterest=3.2f;
    public Bank()
    {
        System.out.println("Bank Constructor called..!!  ");
    }
    public float getDetails()
    {
        return general_rateOfInterest;
    }
}
class SBI extends Bank
{
    private float sbi_rateOfInterest;
    public SBI(float rate)
    {
        sbi_rateOfInterest=rate;
        System.out.println("SBI constructor called.");
    }
    public float getDetails()
    {
        //System.out.println(super.getDetails()+sbi_rateOfInterest);
        return super.getDetails()+sbi_rateOfInterest;
    }
}
class ICICI extends Bank
{
    private float icici_rateOfInterest;
    public ICICI(float rate)
    {
        icici_rateOfInterest=rate;
        System.out.println("ICICI constructor called.");
    }
    public float getDetails()
    {
        return super.getDetails()+icici_rateOfInterest;
    }
}

class BOI extends  Bank
{
    private float boi_rateOfInterest;
    public BOI(float rate)
    {
        boi_rateOfInterest=rate;
        System.out.println("BOI constructor called.");
    }
    public float getDetails()
    {
        return super.getDetails()+boi_rateOfInterest;
    }
}

//main method class
public class BankUtility
{
    public static void main(String[] args)
    {
        Scanner input=new Scanner(System.in);
        System.out.println("enter the interest for sbi: ");
        float interest_sbi=input.nextFloat();
        Bank sbi_bank=new SBI(interest_sbi);
        System.out.println("The total rate of interest including fixed Rate of Bank+ SBI rate: "+
                (float)sbi_bank.getDetails()+" %");

        System.out.println("\nenter the interest for icici: ");
        float interest_icici=input.nextFloat();
        Bank icici_bank=new ICICI(interest_icici);
        System.out.println("The total rate of interest including fixed Rate of Bank+ ICICI rate: "+
                (float)icici_bank.getDetails()+" %");

        System.out.println("\nenter the interest for boi: ");
        float interest_boi=input.nextFloat();
        Bank boi_bank=new ICICI(interest_boi);
        System.out.println("The total rate of interest including fixed Rate of Bank+ BOI rate: "+
                (float)boi_bank.getDetails()+" %");
    }
}


