package com.ttn_assignment_javaone;
import java.util.Scanner;
public class Overloading_IntDoubleStringFloat
{
    void addNumbers(int num1,int num2)
    {
        int add_result_int=num1+num2;
        System.out.println("Adding two integer numbers: "+add_result_int);
    }
    void addNumbers(double num1,double num2)
    {
        double add_result_double=num1+num2;
        System.out.println("Adding two double numbers: "+add_result_double);
    }
    // multiply numbers methods
    void multiplyNumbers(int num1,int num2)
    {
        int mul_result_int=num1*num2;
        System.out.println("Multiply two integer numbers: "+mul_result_int);
    }

    void multiplyNumbers(float num1, float num2)
    {
        float mul_result_float=num1*num2;
        System.out.println("Multiply two float numbers: "+mul_result_float);
    }

    // concat methods for strings
    void concatStrings(String first, String second)   //concat 2 strings
    {
        String concat2strings=first+" "+second;
        System.out.println("Concatenated 2 strings: "+concat2strings);
    }
    void concatStrings(String first,String second,String third) // concat 3 strings
    {
        String concat3strings=first+" "+second+" "+third;
        System.out.println("Concatenated 3 strings: "+concat3strings);
    }
    public static void main(String[] args)
    {
        Overloading_IntDoubleStringFloat obj_=new Overloading_IntDoubleStringFloat();
        Scanner input=new Scanner(System.in);
        System.out.print("Enter 2 integer numbers: ");
        int num1=input.nextInt(),num2=input.nextInt();
        obj_.addNumbers(num1,num2); obj_.multiplyNumbers(num1,num2);

        System.out.print("\nEnter 2 float numbers: ");
        float num1_float=input.nextFloat(),num2_float=input.nextFloat();
        obj_.multiplyNumbers(num1_float,num2_float);

        System.out.print("\nEnter 2 double numbers: ");
        double num1_double=input.nextDouble(),num2_double=input.nextDouble();
        obj_.addNumbers(num1_double,num2_double);

        System.out.print("\nEnter 2 strings: ");
        String string_1=input.next(),string_2=input.next();
        obj_.concatStrings(string_1,string_2);

        System.out.print("\nEnter the 3rd string: "); String string_3=input.next();
        obj_.concatStrings(string_1,string_2,string_3);

    }
}
