package com.ttn_assignment_javaone;
enum House_Cost
{
    FLAT(2000),VILLA(1500),HUT(500);
    private int price;
    House_Cost(int price)
    {
        this.price=price;
    }
    public int getPrice()
    {return price;}
}
public class Enum_Class
{
    public static void main(String[] args)
    {
        House_Cost hc;
        System.out.println("Prices of all Houses are:: \n");
        for(House_Cost house: House_Cost.values())
            System.out.println("cost of  "+house+" is: "+house.getPrice());
    }
}
