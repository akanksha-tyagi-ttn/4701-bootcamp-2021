package com.ttn_assignment_javaone;
import java.util.Scanner;

public class WordOccurrence {
    public static void main(String[] args)
    {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the string::  ");
        String stringToTest= input.nextLine();
        findDuplicateOccurrence(stringToTest); // calling the function
    }

    static void findDuplicateOccurrence(String testString)
    {
        int count=1;
        String[] stringArray=testString.toLowerCase().split("[^a-z]");
        for(int firstWord=0;firstWord<stringArray.length;firstWord++)
        {
            count=1;
            for(int nextWord=firstWord+1;nextWord<stringArray.length;nextWord++)
            {
                if(stringArray[firstWord].equals(stringArray[nextWord]))
                {
                    count++;
                    stringArray[nextWord]="-";
                } // if under for nextWord
            } // for nextWord

            if(count>1 && !stringArray[firstWord].equals("-"))
                System.out.println(stringArray[firstWord]+": "+count);
        } //for firstWord

    } // function
} // class
