package com.ttn_assignment_javaone;
import java.util.Scanner;
public class SingleElementInArrayOfRepeatedElements
{
    public static void main(String[] args)
    {
        Scanner input=new Scanner((System.in));
        System.out.println("Enter the size of the array: ");
        int size= input.nextInt();
        int[] arrInt=new int[size];
        System.out.println("Enter the elements in the array::  ");
        for(int i=0;i<size;i++)
            arrInt[i]=input.nextInt();
        System.out.println("The array Elements are: ");
        displayArrayElements(arrInt,size);
        findSingle(arrInt,size);
    }
    static void displayArrayElements(int[] arrayInt,int size)
    {
        for(int i=0;i<size;i++)
            System.out.print(arrayInt[i]+" ");
        System.out.println();
    }
    static void findSingle(int[] arrayInt,int size)
    {
        int resultElement=arrayInt[0];
        for(int i=1;i<size;i++)
        {
            resultElement^=arrayInt[i];
        }
        System.out.println("The single element in the array: "+resultElement);
    }
}