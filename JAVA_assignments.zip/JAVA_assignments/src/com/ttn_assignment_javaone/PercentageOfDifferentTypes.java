package com.ttn_assignment_javaone;
import java.util.Scanner;
public class PercentageOfDifferentTypes
{
    public static void main(String[] args)
    {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter the string::  ");
        String stringToTest= input.nextLine();
        System.out.println(stringToTest);
        percentageCalculation(stringToTest);
    }
    static void percentageCalculation(String stringTest)
    {
        int totalLength=stringTest.length();
        int uppercaseChar=0,lowercaseChar=0,specialChar=0,digits=0;
        for(int i=0;i<totalLength;i++)
        {
            char character=stringTest.charAt(i);
            if(Character.isUpperCase(character))
                uppercaseChar++;
            else if(Character.isLowerCase(character))
                lowercaseChar++;
            else if(Character.isDigit(character))
                digits++;
            else
                specialChar++;
        }
        System.out.println("The % of UpperCase characters:: "+
                (((float)uppercaseChar*100)/totalLength)+"%");
        System.out.println("The % of LowerCase characters:: "+
                (((float)lowercaseChar*100)/totalLength)+"%");
        System.out.println("The % of digits :: "+
                (((float)digits*100)/totalLength)+"%");
        System.out.println("The % of special characters:: "+
                (((float)specialChar*100)/totalLength)+"%");
    }
}
